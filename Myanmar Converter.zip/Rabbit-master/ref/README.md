## Using Tools

### Keyboard

- KeyMagic
	- Zawgyi Keyboard
	- MyanSan Unicode Keyboard

### Character To Unicode number

- [rishihda's unicode code converter](https://r12a.github.io/apps/conversion/)

### Characters Map

Unicode Code Point Image From [my.wikipedia.org](http://my.wikipedia.org/wiki/File:Unicode_character_map_(color).png)

![unicode_map](Unicode_character_map_(color).png)

Zawgyi Code Point Image From [my.wikipedia.org](http://my.wikipedia.org/wiki/File:Zawgyi_character_map_(color).png)

![zawgyi_map](Zawgyi_character_map_(color).png)
