# Module for Rabbit Version
module Rabbit
  VERSION = '1.0.0'
end
