require './Rabbit'

k = Rabbit::Converter.new
puts k.zg2uni("ေနေကာင္္းလား")
