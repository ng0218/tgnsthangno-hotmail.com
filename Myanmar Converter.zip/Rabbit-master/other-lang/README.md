# To Support Other Languages
Todo

- [x] Java
- [x] Objective-C
- [x] Swift
- [x] Python
- [x] PHP
- [x] Ruby
- [x] C#
- [x] Kotlin

## For Java

- required [java-json](http://www.java2s.com/Code/JarDownload/java/java-json.jar.zip) or you can find in `java-json` folder

## For C-Sharp

- add `System.Web.Extensions` in **Reference** for mono