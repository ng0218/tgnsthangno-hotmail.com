<?php

require("Rabbit.php");

echo Rabbit::zg2uni("ေနေကာင္္း");