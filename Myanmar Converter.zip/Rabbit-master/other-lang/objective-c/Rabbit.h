//
//  Rabbit.h
//  rabbit
//
//  Created by Htain Lin Shwe on 28/1/15.
//  Copyright (c) 2015 comquas. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Rabbit : NSObject
+ (NSString *)uni2zg:(NSString *)zawgyi;
+ (NSString *)zg2uni:(NSString *)unicode;
@end
